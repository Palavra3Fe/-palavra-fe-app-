// <stdin>
import React, { useState } from "https://esm.sh/react@18.2.0";
var { useStoredState } = hatch;
var BibleDevotionalApp = () => {
  const [currentSection, setCurrentSection] = useState("home");
  const [readingProgress, setReadingProgress] = useStoredState("readingProgress", 0);
  const devotionals = [
    {
      id: 1,
      title: "Esperando o Milagre de Deus",
      verse: "Isa\xEDas 40:31",
      text: "Mas os que esperam no Senhor renovar\xE3o as suas for\xE7as; subir\xE3o com asas como \xE1guias; correr\xE3o, e n\xE3o se cansar\xE3o; caminhar\xE3o, e n\xE3o se fatigar\xE3o.",
      message: "Queridos pais e casais, o tempo de Deus \xE9 perfeito. Enquanto esperamos pelo milagre que Ele tem preparado, fortale\xE7amos nossa f\xE9 atrav\xE9s da ora\xE7\xE3o e da Palavra. Deus conhece nossos cora\xE7\xF5es e nossos desejos mais profundos."
    },
    {
      id: 2,
      title: "Jesus \xE9 o Caminho",
      verse: "Jo\xE3o 14:6",
      text: "Disse-lhe Jesus: Eu sou o caminho, e a verdade, e a vida; ningu\xE9m vem ao Pai, sen\xE3o por mim.",
      message: "N\xE3o h\xE1 atalhos para chegar a Deus. Jesus \xE9 o \xFAnico caminho verdadeiro. Quando as dificuldades aparecem, lembremo-nos que Ele j\xE1 venceu o mundo e nos deu a vit\xF3ria atrav\xE9s da cruz."
    },
    {
      id: 3,
      title: "F\xE9 que Move Montanhas",
      verse: "Mateus 17:20",
      text: "Por causa da pequenez da vossa f\xE9; pois em verdade vos digo que, se tiverdes f\xE9 como um gr\xE3o de mostarda, direis a este monte: Passa daqui para acol\xE1, e ele passar\xE1; e nada vos ser\xE1 imposs\xEDvel.",
      message: "Mesmo a menor f\xE9 pode mover montanhas. N\xE3o desprezemos nossa f\xE9, por menor que pare\xE7a. Deus pode fazer grandes coisas atrav\xE9s de cora\xE7\xF5es simples e sinceros."
    }
  ];
  const hopeMessages = [
    "Deus tem um plano perfeito para sua vida. Confie nEle!",
    "Sua ora\xE7\xE3o foi ouvida. Deus est\xE1 trabalhando em seu favor.",
    "N\xE3o desista. O milagre est\xE1 mais perto do que voc\xEA imagina.",
    "Deus nunca chega tarde. Ele sempre chega na hora certa.",
    "Sua f\xE9 \xE9 preciosa aos olhos do Senhor. Continue firme!",
    "O que Deus tem preparado para voc\xEA \xE9 maior que seus problemas.",
    "Cada dia \xE9 uma nova oportunidade de ver a bondade de Deus."
  ];
  const bibleVerses = [
    {
      reference: "Salmos 23:1",
      text: "O Senhor \xE9 o meu pastor; nada me faltar\xE1."
    },
    {
      reference: "Filipenses 4:13",
      text: "Posso todas as coisas naquele que me fortalece."
    },
    {
      reference: "Jeremias 29:11",
      text: "Porque eu bem sei os pensamentos que tenho a vosso respeito, diz o Senhor; pensamentos de paz, e n\xE3o de mal, para vos dar o fim que esperais."
    },
    {
      reference: "Romanos 8:28",
      text: "E sabemos que todas as coisas contribuem juntamente para o bem daqueles que amam a Deus, daqueles que s\xE3o chamados segundo o seu prop\xF3sito."
    }
  ];
  const getCurrentDevotional = () => {
    const today = (/* @__PURE__ */ new Date()).getDate();
    return devotionals[today % devotionals.length];
  };
  const getCurrentHopeMessage = () => {
    const today = (/* @__PURE__ */ new Date()).getDate();
    return hopeMessages[today % hopeMessages.length];
  };
  const renderHome = () => /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement("h1", { className: "text-3xl font-bold text-blue-800 mb-2" }, "Bem-vindos \xE0 Palavra"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-600" }, "Fortalecendo sua f\xE9 atrav\xE9s da Palavra de Deus")), /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg" }, /* @__PURE__ */ React.createElement("h2", { className: "text-xl font-semibold text-blue-800 mb-3" }, "Mensagem de Esperan\xE7a para Hoje"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-700 italic text-lg" }, getCurrentHopeMessage())), /* @__PURE__ */ React.createElement("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setCurrentSection("devotional"),
      className: "bg-blue-600 text-white p-6 rounded-lg hover:bg-blue-700 transition-colors"
    },
    /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-2" }, "Devocional Di\xE1rio"),
    /* @__PURE__ */ React.createElement("p", { className: "text-blue-100" }, "Palavra de encorajamento para hoje")
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setCurrentSection("bible"),
      className: "bg-green-600 text-white p-6 rounded-lg hover:bg-green-700 transition-colors"
    },
    /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold mb-2" }, "Leitura B\xEDblica"),
    /* @__PURE__ */ React.createElement("p", { className: "text-green-100" }, "Vers\xEDculos para fortalecer sua f\xE9")
  )));
  const renderDevotional = () => {
    const devotional = getCurrentDevotional();
    return /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-blue-800 mb-2" }, "Devocional de Hoje"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-600" }, "Palavra de encorajamento para pais e casais")), /* @__PURE__ */ React.createElement("div", { className: "bg-white border-l-4 border-blue-600 p-6 rounded-lg shadow-md" }, /* @__PURE__ */ React.createElement("h3", { className: "text-xl font-semibold text-blue-800 mb-4" }, devotional.title), /* @__PURE__ */ React.createElement("div", { className: "bg-blue-50 p-4 rounded-lg mb-4" }, /* @__PURE__ */ React.createElement("p", { className: "text-sm text-blue-600 font-medium mb-2" }, devotional.verse), /* @__PURE__ */ React.createElement("p", { className: "text-gray-800 italic" }, '"', devotional.text, '"')), /* @__PURE__ */ React.createElement("div", { className: "prose max-w-none" }, /* @__PURE__ */ React.createElement("p", { className: "text-gray-700 leading-relaxed" }, devotional.message))), /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement("p", { className: "text-sm text-gray-500 mb-4" }, "Leve esta palavra no seu cora\xE7\xE3o hoje"), /* @__PURE__ */ React.createElement(
      "button",
      {
        onClick: () => setCurrentSection("home"),
        className: "text-blue-600 hover:text-blue-800 font-medium"
      },
      "\u2190 Voltar ao In\xEDcio"
    )));
  };
  const renderBible = () => /* @__PURE__ */ React.createElement("div", { className: "space-y-6" }, /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement("h2", { className: "text-2xl font-bold text-green-800 mb-2" }, "Leitura B\xEDblica"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-600" }, "Vers\xEDculos para fortalecer sua caminhada")), /* @__PURE__ */ React.createElement("div", { className: "space-y-4" }, bibleVerses.map((verse, index) => /* @__PURE__ */ React.createElement("div", { key: index, className: "bg-white border-l-4 border-green-600 p-4 rounded-lg shadow-md" }, /* @__PURE__ */ React.createElement("p", { className: "text-green-600 font-medium text-sm mb-2" }, verse.reference), /* @__PURE__ */ React.createElement("p", { className: "text-gray-800 text-lg italic" }, '"', verse.text, '"')))), /* @__PURE__ */ React.createElement("div", { className: "bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg" }, /* @__PURE__ */ React.createElement("h3", { className: "text-lg font-semibold text-green-800 mb-3" }, "Reflex\xE3o"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-700" }, "A Palavra de Deus \xE9 l\xE2mpada para os nossos p\xE9s e luz para o nosso caminho. Medite nestes vers\xEDculos e deixe que eles fortale\xE7am sua f\xE9 e renovem sua esperan\xE7a. Deus est\xE1 com voc\xEA em cada passo da jornada.")), /* @__PURE__ */ React.createElement("div", { className: "text-center" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setCurrentSection("home"),
      className: "text-green-600 hover:text-green-800 font-medium"
    },
    "\u2190 Voltar ao In\xEDcio"
  )));
  return /* @__PURE__ */ React.createElement("div", { className: "min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4" }, /* @__PURE__ */ React.createElement("div", { className: "max-w-4xl mx-auto" }, /* @__PURE__ */ React.createElement("div", { className: "text-center mb-8" }, /* @__PURE__ */ React.createElement("div", { className: "inline-flex items-center justify-center w-16 h-16 bg-white rounded-full shadow-lg mb-4" }, /* @__PURE__ */ React.createElement("span", { className: "text-2xl" }, "\u{1F4D6}")), /* @__PURE__ */ React.createElement("h1", { className: "text-2xl font-bold text-gray-800" }, "Palavra & F\xE9"), /* @__PURE__ */ React.createElement("p", { className: "text-gray-600 text-sm" }, "Aplicativo Crist\xE3o para Fortalecer sua F\xE9")), /* @__PURE__ */ React.createElement("div", { className: "flex justify-center mb-6" }, /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-md p-1 flex space-x-1" }, /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setCurrentSection("home"),
      className: `px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentSection === "home" ? "bg-blue-600 text-white" : "text-gray-600 hover:text-blue-600"}`
    },
    "In\xEDcio"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setCurrentSection("devotional"),
      className: `px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentSection === "devotional" ? "bg-blue-600 text-white" : "text-gray-600 hover:text-blue-600"}`
    },
    "Devocional"
  ), /* @__PURE__ */ React.createElement(
    "button",
    {
      onClick: () => setCurrentSection("bible"),
      className: `px-4 py-2 rounded-md text-sm font-medium transition-colors ${currentSection === "bible" ? "bg-blue-600 text-white" : "text-gray-600 hover:text-blue-600"}`
    },
    "B\xEDblia"
  ))), /* @__PURE__ */ React.createElement("div", { className: "bg-white rounded-lg shadow-lg p-6" }, currentSection === "home" && renderHome(), currentSection === "devotional" && renderDevotional(), currentSection === "bible" && renderBible()), /* @__PURE__ */ React.createElement("div", { className: "text-center mt-8 text-gray-500 text-sm" }, /* @__PURE__ */ React.createElement("p", null, '"Jesus disse: Eu sou o caminho, e a verdade, e a vida" - Jo\xE3o 14:6'), /* @__PURE__ */ React.createElement("p", { className: "mt-2" }, "Que Deus aben\xE7oe sua caminhada de f\xE9 \u{1F64F}"))));
};
var stdin_default = BibleDevotionalApp;
export {
  stdin_default as default
};
