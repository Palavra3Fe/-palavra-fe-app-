import React, { useState } from 'react';
const { useStoredState } = hatch;

const BibleDevotionalApp = () => {
  const [currentSection, setCurrentSection] = useState('home');
  const [readingProgress, setReadingProgress] = useStoredState('readingProgress', 0);
  
  const devotionals = [
    {
      id: 1,
      title: "Esperando o Milagre de Deus",
      verse: "Isaías 40:31",
      text: "Mas os que esperam no Senhor renovarão as suas forças; subirão com asas como águias; correrão, e não se cansarão; caminharão, e não se fatigarão.",
      message: "Queridos pais e casais, o tempo de Deus é perfeito. Enquanto esperamos pelo milagre que Ele tem preparado, fortaleçamos nossa fé através da oração e da Palavra. Deus conhece nossos corações e nossos desejos mais profundos."
    },
    {
      id: 2,
      title: "Jesus é o Caminho",
      verse: "João 14:6",
      text: "Disse-lhe Jesus: Eu sou o caminho, e a verdade, e a vida; ninguém vem ao Pai, senão por mim.",
      message: "Não há atalhos para chegar a Deus. Jesus é o único caminho verdadeiro. Quando as dificuldades aparecem, lembremo-nos que Ele já venceu o mundo e nos deu a vitória através da cruz."
    },
    {
      id: 3,
      title: "Fé que Move Montanhas",
      verse: "Mateus 17:20",
      text: "Por causa da pequenez da vossa fé; pois em verdade vos digo que, se tiverdes fé como um grão de mostarda, direis a este monte: Passa daqui para acolá, e ele passará; e nada vos será impossível.",
      message: "Mesmo a menor fé pode mover montanhas. Não desprezemos nossa fé, por menor que pareça. Deus pode fazer grandes coisas através de corações simples e sinceros."
    }
  ];

  const hopeMessages = [
    "Deus tem um plano perfeito para sua vida. Confie nEle!",
    "Sua oração foi ouvida. Deus está trabalhando em seu favor.",
    "Não desista. O milagre está mais perto do que você imagina.",
    "Deus nunca chega tarde. Ele sempre chega na hora certa.",
    "Sua fé é preciosa aos olhos do Senhor. Continue firme!",
    "O que Deus tem preparado para você é maior que seus problemas.",
    "Cada dia é uma nova oportunidade de ver a bondade de Deus."
  ];

  const bibleVerses = [
    {
      reference: "Salmos 23:1",
      text: "O Senhor é o meu pastor; nada me faltará."
    },
    {
      reference: "Filipenses 4:13",
      text: "Posso todas as coisas naquele que me fortalece."
    },
    {
      reference: "Jeremias 29:11",
      text: "Porque eu bem sei os pensamentos que tenho a vosso respeito, diz o Senhor; pensamentos de paz, e não de mal, para vos dar o fim que esperais."
    },
    {
      reference: "Romanos 8:28",
      text: "E sabemos que todas as coisas contribuem juntamente para o bem daqueles que amam a Deus, daqueles que são chamados segundo o seu propósito."
    }
  ];

  const getCurrentDevotional = () => {
    const today = new Date().getDate();
    return devotionals[today % devotionals.length];
  };

  const getCurrentHopeMessage = () => {
    const today = new Date().getDate();
    return hopeMessages[today % hopeMessages.length];
  };

  const renderHome = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-blue-800 mb-2">Bem-vindos à Palavra</h1>
        <p className="text-gray-600">Fortalecendo sua fé através da Palavra de Deus</p>
      </div>
      
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg">
        <h2 className="text-xl font-semibold text-blue-800 mb-3">Mensagem de Esperança para Hoje</h2>
        <p className="text-gray-700 italic text-lg">{getCurrentHopeMessage()}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button
          onClick={() => setCurrentSection('devotional')}
          className="bg-blue-600 text-white p-6 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <h3 className="text-lg font-semibold mb-2">Devocional Diário</h3>
          <p className="text-blue-100">Palavra de encorajamento para hoje</p>
        </button>
        
        <button
          onClick={() => setCurrentSection('bible')}
          className="bg-green-600 text-white p-6 rounded-lg hover:bg-green-700 transition-colors"
        >
          <h3 className="text-lg font-semibold mb-2">Leitura Bíblica</h3>
          <p className="text-green-100">Versículos para fortalecer sua fé</p>
        </button>
      </div>
    </div>
  );

  const renderDevotional = () => {
    const devotional = getCurrentDevotional();
    
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-blue-800 mb-2">Devocional de Hoje</h2>
          <p className="text-gray-600">Palavra de encorajamento para pais e casais</p>
        </div>
        
        <div className="bg-white border-l-4 border-blue-600 p-6 rounded-lg shadow-md">
          <h3 className="text-xl font-semibold text-blue-800 mb-4">{devotional.title}</h3>
          
          <div className="bg-blue-50 p-4 rounded-lg mb-4">
            <p className="text-sm text-blue-600 font-medium mb-2">{devotional.verse}</p>
            <p className="text-gray-800 italic">"{devotional.text}"</p>
          </div>
          
          <div className="prose max-w-none">
            <p className="text-gray-700 leading-relaxed">{devotional.message}</p>
          </div>
        </div>
        
        <div className="text-center">
          <p className="text-sm text-gray-500 mb-4">Leve esta palavra no seu coração hoje</p>
          <button
            onClick={() => setCurrentSection('home')}
            className="text-blue-600 hover:text-blue-800 font-medium"
          >
            ← Voltar ao Início
          </button>
        </div>
      </div>
    );
  };

  const renderBible = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-green-800 mb-2">Leitura Bíblica</h2>
        <p className="text-gray-600">Versículos para fortalecer sua caminhada</p>
      </div>
      
      <div className="space-y-4">
        {bibleVerses.map((verse, index) => (
          <div key={index} className="bg-white border-l-4 border-green-600 p-4 rounded-lg shadow-md">
            <p className="text-green-600 font-medium text-sm mb-2">{verse.reference}</p>
            <p className="text-gray-800 text-lg italic">"{verse.text}"</p>
          </div>
        ))}
      </div>
      
      <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg">
        <h3 className="text-lg font-semibold text-green-800 mb-3">Reflexão</h3>
        <p className="text-gray-700">
          A Palavra de Deus é lâmpada para os nossos pés e luz para o nosso caminho. 
          Medite nestes versículos e deixe que eles fortaleçam sua fé e renovem sua esperança. 
          Deus está com você em cada passo da jornada.
        </p>
      </div>
      
      <div className="text-center">
        <button
          onClick={() => setCurrentSection('home')}
          className="text-green-600 hover:text-green-800 font-medium"
        >
          ← Voltar ao Início
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white rounded-full shadow-lg mb-4">
            <span className="text-2xl">📖</span>
          </div>
          <h1 className="text-2xl font-bold text-gray-800">Palavra & Fé</h1>
          <p className="text-gray-600 text-sm">Aplicativo Cristão para Fortalecer sua Fé</p>
        </div>

        {/* Navigation */}
        <div className="flex justify-center mb-6">
          <div className="bg-white rounded-lg shadow-md p-1 flex space-x-1">
            <button
              onClick={() => setCurrentSection('home')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                currentSection === 'home' 
                  ? 'bg-blue-600 text-white' 
                  : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              Início
            </button>
            <button
              onClick={() => setCurrentSection('devotional')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                currentSection === 'devotional' 
                  ? 'bg-blue-600 text-white' 
                  : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              Devocional
            </button>
            <button
              onClick={() => setCurrentSection('bible')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                currentSection === 'bible' 
                  ? 'bg-blue-600 text-white' 
                  : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              Bíblia
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="bg-white rounded-lg shadow-lg p-6">
          {currentSection === 'home' && renderHome()}
          {currentSection === 'devotional' && renderDevotional()}
          {currentSection === 'bible' && renderBible()}
        </div>

        {/* Footer */}
        <div className="text-center mt-8 text-gray-500 text-sm">
          <p>"Jesus disse: Eu sou o caminho, e a verdade, e a vida" - João 14:6</p>
          <p className="mt-2">Que Deus abençoe sua caminhada de fé 🙏</p>
        </div>
      </div>
    </div>
  );
};

export default BibleDevotionalApp;